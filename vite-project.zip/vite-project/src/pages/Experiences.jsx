import React from "react";
import Card from "../components/Card";
import CategoryBar from "../components/CategoryBar";

const sampleExperiences = [
  { id: "exp-1", image: "/assets/exp1.jpg", title: "Street Food Tour", location: "Manila, Philippines", price: "₱1,200 / person", rating: 4.9 },
  { id: "exp-2", image: "/assets/exp2.jpg", title: "Island Hopping", location: "Cebu, Philippines", price: "₱2,500 / person", rating: 4.8 },
  { id: "exp-3", image: "/assets/exp3.jpg", title: "Rice Terrace Trek", location: "Banaue, Philippines", price: "₱1,800 / person", rating: 4.7 },
];

export default function Experiences() {
  const rows = Array.from({ length: 4 }).map((_, r) =>
    Array.from({ length: 6 }).map((_, i) => {
      const base = sampleExperiences[i % sampleExperiences.length];
      return { ...base, id: `${base.id}-${r}-${i}` };
    })
  );

  return (
    <section className="page">
      <CategoryBar />
      <div className="page-inner">
        <h2 className="section-title">Experiences</h2>
        <div className="grid-rows">
          {rows.map((row, rIdx) => (
            <div className="row" key={rIdx}>
              {row.map(item => (
                <Card key={item.id} {...item} />
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
