import React from "react";
import Card from "../components/Card";
import city from "../assets/city1.jpg";

function Listings() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-3">All Listings</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {Array.from({ length: 12 }).map((_, i) => (
          <Card
            key={i}
            image={city}
            title={`Listing ${i + 1}`}
            price={`$${120 + i * 5}/night`}
          />
        ))}
      </div>
    </div>
  );
}

export default Listings;
