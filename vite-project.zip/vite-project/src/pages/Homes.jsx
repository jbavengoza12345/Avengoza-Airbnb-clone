import React from "react";
import Card from "../components/Card";
import CategoryBar from "../components/CategoryBar";

const sampleHomes = [
  { id: "home-1", image: "/assets/home1.jpg", title: "Cozy Beach House", location: "Boracay, Philippines", price: "₱5,000 / night", rating: 4.8 },
  { id: "home-2", image: "/assets/home2.jpg", title: "Modern Condo", location: "Makati, Philippines", price: "₱3,200 / night", rating: 4.6 },
  { id: "home-3", image: "/assets/home3.jpg", title: "Mountain Cabin", location: "Baguio, Philippines", price: "₱2,900 / night", rating: 4.7 },
];

export default function Homes() {
  const rows = Array.from({ length: 4 }).map((_, r) =>
    Array.from({ length: 6 }).map((_, i) => {
      const base = sampleHomes[i % sampleHomes.length];
      return { ...base, id: `${base.id}-${r}-${i}` };
    })
  );

  return (
    <section className="page">
      <CategoryBar />
      <div className="page-inner">
        <h2 className="section-title">Homes</h2>
        <div className="grid-rows">
          {rows.map((row, rIdx) => (
            <div className="row" key={rIdx}>
              {row.map(item => (
                <Card key={item.id} {...item} />
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}