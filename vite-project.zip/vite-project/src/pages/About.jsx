import React from "react";

function About() {
  return (
    <div className="max-w-3xl mx-auto text-center">
      <h2 className="text-2xl font-bold mb-4">About This Project</h2>
      <p className="text-gray-600">
        This Airbnb-style clone is a practice project built with React, Vite, 
        and Tailwind CSS. It features categories, listings, a search bar, and 
        navigation similar to Airbnb’s structure.
      </p>
    </div>
  );
}

export default About;
