import React from "react";
import { useParams } from "react-router-dom";

export default function ListingDetail() {
  const { id } = useParams();

  return (
    <section className="page-inner">
      <h2 className="section-title">Listing Detail</h2>
      <p>Showing details for: {id}</p>

      {/* Image Gallery */}
      <div className="detail-gallery">
        <div className="gallery-main">
          <img src="/assets/home1.jpg" alt="Main" />
        </div>
        <div className="gallery-thumbs">
          <img src="/assets/home2.jpg" alt="thumb" />
          <img src="/assets/home3.jpg" alt="thumb" />
          <img src="/assets/exp1.jpg" alt="thumb" />
          <img src="/assets/exp2.jpg" alt="thumb" />
        </div>
      </div>

      {/* Info + Reserve */}
      <div className="detail-layout">
        <div className="detail-info">
          <h3>Spacious 1BR (54sqm) w/ Balcony Taal View</h3>
          <p className="detail-sub">Entire condo in Tagaytay, Philippines</p>
          <ul className="detail-meta">
            <li>4 guests · 1 bedroom · 1 bed · 1 bath</li>
            <li>⭐ 4.96 (48 reviews)</li>
          </ul>
          <p className="detail-desc">
            Our spacious and cozy rental offers a private balcony showcasing breathtaking views.
            Whether you're planning a romantic escape, a family vacation, or a trip with friends,
            our home is designed to provide a comfortable stay for everyone.
          </p>
        </div>

        <aside className="reserve-box">
          <div className="price">₱5,953 / 2 nights</div>
          <button className="reserve-btn">Reserve</button>
        </aside>
      </div>
    </section>
  );
}
