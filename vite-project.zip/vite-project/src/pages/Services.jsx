import React from "react";
import Card from "../components/Card";
import CategoryBar from "../components/CategoryBar";

const sampleServices = [
  { id: "srv-1", image: "/assets/service1.jpg", title: "Airport Pickup", location: "Nationwide", price: "₱800 / service", rating: 4.6 },
  { id: "srv-2", image: "/assets/service2.jpg", title: "House Cleaning", location: "Metro Manila", price: "₱1,500 / service", rating: 4.7 },
  { id: "srv-3", image: "/assets/service3.jpg", title: "Private Chef", location: "Makati", price: "₱3,000 / event", rating: 4.9 },
];

export default function Services() {
  const rows = Array.from({ length: 4 }).map((_, r) =>
    Array.from({ length: 6 }).map((_, i) => {
      const base = sampleServices[i % sampleServices.length];
      return { ...base, id: `${base.id}-${r}-${i}` };
    })
  );

  return (
    <section className="page">
      <CategoryBar />
      <div className="page-inner">
        <h2 className="section-title">Services</h2>
        <div className="grid-rows">
          {rows.map((row, rIdx) => (
            <div className="row" key={rIdx}>
              {row.map(item => (
                <Card key={item.id} {...item} />
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
