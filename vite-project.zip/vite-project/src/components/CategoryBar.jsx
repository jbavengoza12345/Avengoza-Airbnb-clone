import React from "react";

const cats = [
  { icon: "🏖️", name: "Beach" },
  { icon: "⛰️", name: "Mountains" },
  { icon: "🏕️", name: "Camping" },
  { icon: "🏙️", name: "City" },
  { icon: "🍷", name: "Food & Drink" },
  { icon: "🎨", name: "Arts" },
  { icon: "💆", name: "Wellness" },
];

export default function CategoryBar() {
  return (
    <div className="category-bar">
      <div className="category-inner">
        {cats.map((c, i) => (
          <button className="category-pill" key={i}>
            <span className="cat-icon">{c.icon}</span>
            <span className="cat-name">{c.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
