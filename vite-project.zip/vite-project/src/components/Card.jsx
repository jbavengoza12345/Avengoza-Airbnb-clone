
import React from "react";
import { Link } from "react-router-dom";

export default function Card({ id, image, title, location, price, rating }) {
  return (
    <Link to={`/listing/${id}`} className="card-link">
      <article className="card">
        <div className="card-media">
          <img src={image} alt={title} />
        </div>
        <div className="card-body">
          <div className="card-top">
            <h3 className="card-title">{title}</h3>
            <span className="card-rating">⭐ {rating}</span>
          </div>
          <p className="card-location">{location}</p>
          <div className="card-bottom">
            <span className="card-price">{price}</span>
          </div>
        </div>
      </article>
    </Link>
  );
}
