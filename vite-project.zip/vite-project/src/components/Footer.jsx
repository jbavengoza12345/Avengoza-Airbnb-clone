import React from "react";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-top">
        <div>
          <h4>Inspiration for future getaways</h4>
          <div className="footer-links-row">
            <a href="#">Travel tips & inspiration</a>
            <a href="#">Airbnb-friendly apartments</a>
          </div>
          <div className="footer-sublinks">
            <a href="#">Family travel hub<br /><span>Tips and inspiration</span></a>
            <a href="#">Family budget travel<br /><span>Get there for less</span></a>
            <a href="#">Vacation ideas for any budget<br /><span>Make it special without making it spendy</span></a>
            <a href="#">Travel Europe on a budget<br /><span>How to take the kids to Europe for less</span></a>
            <a href="#">Outdoor adventure<br /><span>Explore nature with the family</span></a>
            <a href="#">Bucket list national parks<br /><span>Must-see parks for family travel</span></a>
            <a href="#">Kid-friendly state parks<br /><span>Check out these family-friendly hikes</span></a>
          </div>
        </div>
      </div>

      <div className="footer-bottom">
        <div>
          <h5>Support</h5>
          <a href="#">Help Center</a>
          <a href="#">Get help with a safety issue</a>
          <a href="#">AirCover</a>
          <a href="#">Anti-discrimination</a>
          <a href="#">Disability support</a>
          <a href="#">Cancellation options</a>
          <a href="#">Report neighborhood concern</a>
        </div>
        <div>
          <h5>Hosting</h5>
          <a href="#">Airbnb your home</a>
          <a href="#">Airbnb your experience</a>
          <a href="#">Airbnb your service</a>
          <a href="#">AirCover for Hosts</a>
          <a href="#">Hosting resources</a>
          <a href="#">Community forum</a>
          <a href="#">Hosting responsibly</a>
          <a href="#">Airbnb-friendly apartments</a>
          <a href="#">Join a free Hosting class</a>
          <a href="#">Find a co-host</a>
        </div>
        <div>
          <h5>Airbnb</h5>
          <a href="#">2025 Summer Release</a>
          <a href="#">Newsroom</a>
          <a href="#">Careers</a>
          <a href="#">Investors</a>
          <a href="#">Gift cards</a>
          <a href="#">Airbnb.org emergency stays</a>
        </div>
      </div>
    </footer>
  );
}
