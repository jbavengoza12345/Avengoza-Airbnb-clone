import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Navbar.css";

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e) => {
    e.preventDefault();
    console.log("Searching for:", searchQuery);
    // You can redirect or filter based on searchQuery
  };

  return (
    <nav className="navbar">
      <div className="nav-left">
        <Link to="/" className="logo">
          <img src="/assets/airbnb-logo.png" alt="Airbnb" />
        </Link>
      </div>

      <div className="nav-center">
        {/* Search Bar */}
        <form className="nav-search" onSubmit={handleSearch}>
          <input
            type="text"
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <button type="submit">🔍</button>
        </form>

        {/* Main Links */}
        <div className="nav-links">
          <Link to="/homes">🏠 Homes</Link>
          <Link to="/experiences">🎈 Experiences</Link>
          <Link to="/services">🛎️ Services</Link>
        </div>
      </div>

      <div className="nav-right">
        <button className="host-btn">Become a host</button>
        <button className="menu-btn" onClick={() => setMenuOpen(!menuOpen)}>
          ☰
        </button>

        {menuOpen && (
          <div className="menu-dropdown">
            <Link to="/help">Help Center</Link>
            <hr />
            <Link to="/login">Log in</Link>
            <Link to="/signup">Sign up</Link>
          </div>
        )}
      </div>
    </nav>
  );
}
