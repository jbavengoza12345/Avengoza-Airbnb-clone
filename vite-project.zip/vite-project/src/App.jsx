import React from "react";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Homes from "./pages/Homes";
import Experiences from "./pages/Experiences";
import Services from "./pages/Services";
import ListingDetail from "./pages/ListingDetail";

// Layout wrapper with conditional footer
function Layout({ children }) {
  const location = useLocation();
  const hideFooter = location.pathname.startsWith("/listing/");

  return (
    <div className="app">
      <Navbar />
      <main className="main">{children}</main>
      {!hideFooter && <Footer />}
    </div>
  );
}

function AppContent() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Homes />} />
        <Route path="/homes" element={<Homes />} />
        <Route path="/experiences" element={<Experiences />} />
        <Route path="/services" element={<Services />} />
        <Route path="/listing/:id" element={<ListingDetail />} />
      </Routes>
    </Layout>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}
